// Listen for live status updates from the content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "UPDATE_STATUS") {
        let statusDiv = document.getElementById('status');
        let text = `Captured: ${request.count} orders.`;
        if (request.status) text += `<br>${request.status}`;
        statusDiv.innerHTML = text;
        statusDiv.style.color = "blue";
    }
});

document.getElementById('downloadBtn').addEventListener('click', async () => {
  let statusDiv = document.getElementById('status');
  statusDiv.innerText = "Connecting to page...";
  
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab.url.includes("loginextsolutions.com")) {
      statusDiv.innerText = "Error: Please open LogiNext.";
      statusDiv.style.color = "red";
      return;
  }

  // Start the scrape
  chrome.tabs.sendMessage(tab.id, {action: "START_AUTOSCRAPE"}, (response) => {
      if (chrome.runtime.lastError) {
          statusDiv.innerText = "Please refresh LogiNext (F5) first.";
          statusDiv.style.color = "red";
      } else {
          statusDiv.innerText = "Auto-Scrape started! Do not touch the mouse.";
          statusDiv.style.color = "green";
      }
  });
});
