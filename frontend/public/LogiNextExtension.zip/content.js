let isScraping = false;
let allCollectedOrders = [];
let allHeaders = [];

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "START_AUTOSCRAPE") {
        // If we are the top window, relay the message to all iframes
        if (window === window.top) {
            let iframes = document.querySelectorAll('iframe');
            iframes.forEach(f => {
                try {
                    f.contentWindow.postMessage({action: "START_AUTOSCRAPE_RELAY"}, "*");
                } catch(e) {}
            });
            
            // Start here too if this window has the LogiNext next button
            if (document.querySelector('.icon-angle-right') && !isScraping) {
                startAutoScrape();
            }
        }
        sendResponse({status: "started"});
    }
});

window.addEventListener("message", function(event) {
    if (event.data && event.data.action === "START_AUTOSCRAPE_RELAY") {
        // Start scraping only if this frame has the LogiNext next button
        if (document.querySelector('.icon-angle-right') && !isScraping) {
            startAutoScrape();
        }
    }
});

function scrapeCurrentPage() {
    // Strictly target the exact LogiNext grid structure
    let headerNodes = Array.from(document.querySelectorAll('[role="columnheader"]'));
    let headers = [];
    
    headerNodes.forEach(node => {
        let text = node.innerText.replace(/"/g, '""').replace(/(\r\n|\n|\r)/gm, ' ').trim();
        if (!text) {
            // Check for title attribute or ID if text is empty (like checkboxes)
            let titleNode = node.querySelector('[title]');
            if (titleNode) text = titleNode.getAttribute('title');
            else text = node.id || `Col_${headers.length}`;
        }
        let rect = node.getBoundingClientRect();
        headers.push({ text: text, left: rect.left });
    });
    
    if (headers.length === 0) return { headers: [], rows: [] };

    // Get Data Cells
    let cellNodes = Array.from(document.querySelectorAll('[role="cell"]'));
    let cells = [];
    cellNodes.forEach(node => {
        let text = node.innerText.replace(/"/g, '""').replace(/(\r\n|\n|\r)/gm, ' ').trim();
        let rect = node.getBoundingClientRect();
        cells.push({ text: text, top: rect.top, left: rect.left });
    });

    if (cells.length === 0) return { headers: [], rows: [] };

    // Group by Top coordinate (virtual rows)
    cells.sort((a, b) => a.top - b.top);
    
    let rowGroups = [];
    let currentRow = [cells[0]];
    let currentTop = cells[0].top;
    
    for (let i = 1; i < cells.length; i++) {
        let item = cells[i];
        if (Math.abs(item.top - currentTop) < 15) {
            currentRow.push(item);
        } else {
            rowGroups.push(currentRow);
            currentRow = [item];
            currentTop = item.top;
        }
    }
    rowGroups.push(currentRow);

    // Map cells to headers based on horizontal position
    let validRows = [];
    rowGroups.forEach(rowCells => {
        let rowData = {};
        headers.forEach(header => {
            let bestCell = null;
            let minDistance = 150; 
            rowCells.forEach(cell => {
                let dist = Math.abs(cell.left - header.left);
                if (dist < minDistance) {
                    minDistance = dist;
                    bestCell = cell;
                }
            });
            // Ignore the selection checkbox column
            if (!header.text.includes('selection') && !header.text.includes('Checkbox')) {
                rowData[header.text] = bestCell ? bestCell.text : "";
            }
        });
        
        validRows.push(rowData);
    });

    // Clean up headers for export
    let finalHeaders = headers.map(h => h.text).filter(t => !t.includes('selection') && !t.includes('Checkbox'));

    return { headers: finalHeaders, rows: validRows };
}

function clickNextButton() {
    // Exact match for the LogiNext Next Button based on HTML snippet
    let rightIcon = document.querySelector('.icon-angle-right');
    if (rightIcon) {
        let btn = rightIcon.closest('button');
        if (btn && !btn.disabled) {
            btn.click();
            return true;
        }
    }
    return false;
}

function getVisibleScrollContainer() {
    // Only select the grid that is actively visible on the screen
    let grids = Array.from(document.querySelectorAll('.variable-size-grid')).filter(el => {
        let rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== 'hidden';
    });
    if (grids.length > 0) return grids[0];
    
    let allDivs = Array.from(document.querySelectorAll('div')).filter(el => {
        let rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== 'hidden';
    });
    
    let bestDiv = null;
    let maxArea = 0;
    for (let div of allDivs) {
        let style = window.getComputedStyle(div);
        if ((style.overflowY === 'auto' || style.overflowY === 'scroll' || style.overflowY === 'overlay') && div.scrollHeight > div.clientHeight) {
            let area = div.clientWidth * div.clientHeight;
            if (area > maxArea) {
                maxArea = area;
                bestDiv = div;
            }
        }
    }
    return bestDiv || document.documentElement;
}

async function startAutoScrape() {
    isScraping = true;
    allCollectedOrders = [];
    allHeaders = [];

    while (isScraping) {
        let scrollContainer = getVisibleScrollContainer();
        
        // Force scroll left to 0 so we never miss the Order No column!
        if (scrollContainer !== document.documentElement) {
            scrollContainer.scrollLeft = 0;
            scrollContainer.scrollTop = 0;
        } else {
            window.scrollTo(0, 0);
        }
        await new Promise(r => setTimeout(r, 800)); // wait for React to render
        
        let reachedBottom = false;
        let lastCount = -1;
        let stuckCounter = 0;

        while (!reachedBottom && isScraping) {
            // Guarantee horizontal scroll is 0 before scraping
            let grids = document.querySelectorAll('.variable-size-grid, .list-container, .columns-container, .rows-container');
            grids.forEach(g => { if (g.scrollLeft > 0) g.scrollLeft = 0; });

            let pageData = scrapeCurrentPage();
            
            if (pageData.headers.length === 0 && allHeaders.length === 0) {
                isScraping = false;
                return;
            }

            if (pageData.headers.length > 0 && allHeaders.length === 0) {
                allHeaders = pageData.headers;
            }
            
            pageData.rows.forEach(newRow => {
                let rowStr = JSON.stringify(newRow);
                if (!allCollectedOrders.find(o => JSON.stringify(o) === rowStr)) {
                    allCollectedOrders.push(newRow);
                }
            });

            chrome.runtime.sendMessage({ action: "UPDATE_STATUS", count: allCollectedOrders.length, status: "Scrolling down page..." });

            if (allCollectedOrders.length === lastCount) {
                stuckCounter++;
                if (stuckCounter >= 3) {
                    reachedBottom = true;
                    continue;
                }
            } else {
                stuckCounter = 0;
                lastCount = allCollectedOrders.length;
            }

            // Scroll vertically ONLY. Use a far-left cell to prevent diagonal scrolling.
            let currentCells = Array.from(document.querySelectorAll('[role="cell"]'));
            let leftCells = currentCells.filter(c => c.getBoundingClientRect().left < 300);
            
            let targetCell = null;
            if (leftCells.length > 0) {
                targetCell = leftCells[leftCells.length - 1];
            } else if (currentCells.length > 0) {
                targetCell = currentCells[currentCells.length - 1];
            }

            if (scrollContainer === document.documentElement) {
                window.scrollBy(0, 500);
            } else {
                let oldScroll = scrollContainer.scrollTop;
                scrollContainer.scrollTop += 500; 
                
                // If native scroll didn't move it, force scroll via the target cell
                if (scrollContainer.scrollTop === oldScroll && targetCell) {
                    // inline: 'nearest' guarantees NO horizontal scrolling
                    targetCell.scrollIntoView({ behavior: 'auto', block: 'start', inline: 'nearest' });
                }
            }
            
            await new Promise(r => setTimeout(r, 600));
        }

        chrome.runtime.sendMessage({ action: "UPDATE_STATUS", count: allCollectedOrders.length, status: "Clicking Next Page..." });

        let nextClicked = clickNextButton();
        if (!nextClicked) {
            chrome.runtime.sendMessage({ action: "UPDATE_STATUS", count: allCollectedOrders.length, status: "Finished! Downloading..." });
            break; 
        }

        await new Promise(r => setTimeout(r, 2500));
    }
    
    if (allCollectedOrders.length > 0) {
        downloadCSV();
    } else {
        alert("LogiNext Auto-Scraper couldn't find any orders on the screen!");
    }
    isScraping = false;
}

function downloadCSV() {
    let headers = Array.from(allHeaders);
    let priorityKeys = ["Order", "Trip", "Delivery"];
    headers.sort((a, b) => {
        let idxA = priorityKeys.findIndex(pk => a.toLowerCase().includes(pk.toLowerCase()));
        let idxB = priorityKeys.findIndex(pk => b.toLowerCase().includes(pk.toLowerCase()));
        if (idxA !== -1 && idxB !== -1) return idxA - idxB;
        if (idxA !== -1) return -1;
        if (idxB !== -1) return 1;
        return a.localeCompare(b);
    });

    let csvContent = "Sequence," + headers.map(h => '"' + h + '"').join(",") + "\r\n";

    allCollectedOrders.forEach((order, index) => {
        let row = [(index + 1).toString()]; 
        headers.forEach(key => {
            let val = order[key];
            if (!val) {
                row.push('""');
            } else {
                row.push('"' + val + '"');
            }
        });
        csvContent += row.join(",") + "\r\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    let dateStr = new Date().toISOString().split('T')[0];
    link.setAttribute("download", `loginext_autosweep_${dateStr}_(${allCollectedOrders.length}_items).csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
