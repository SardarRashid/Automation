(function() {
    // --- 1. Intercept older XHR Requests ---
    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        this.addEventListener('load', function() {
            let requestUrl = String(url || this.responseURL || '');
            if (requestUrl.includes('fmlm') && requestUrl.includes('dataFetchMode=DATA')) {
                try {
                    const response = JSON.parse(this.responseText);
                    if (response && response.data && response.data.results) {
                        window.postMessage({ type: 'LOGINEXT_EXTRACTED_ORDERS', orders: response.data.results }, '*');
                    }
                } catch (e) {
                    console.error("LogiNext Downloader XHR Error:", e);
                }
            }
        });
        originalOpen.apply(this, arguments);
    };

    // --- 2. Intercept modern Fetch Requests ---
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const response = await originalFetch.apply(this, args);
        try {
            let requestUrl = String(args[0] && args[0].url ? args[0].url : args[0]);
            if (requestUrl.includes('fmlm') && requestUrl.includes('dataFetchMode=DATA')) {
                const clone = response.clone();
                clone.json().then(data => {
                    if (data && data.data && data.data.results) {
                        window.postMessage({ type: 'LOGINEXT_EXTRACTED_ORDERS', orders: data.data.results }, '*');
                    }
                }).catch(e => console.error("LogiNext Downloader Fetch JSON Error:", e));
            }
        } catch (e) {
            console.error("LogiNext Downloader Fetch Intercept Error:", e);
        }
        return response;
    };
})();
